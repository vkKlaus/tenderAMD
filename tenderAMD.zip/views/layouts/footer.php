
    </main>

<footer class="container-fluid footer text-center bg-dark text-secondary mt-5">
    <div>&copy;&emsp;Vladislav A. Klokol&emsp;2020</div>
</footer>
<script src="/js/jquery-3.4.1.min.js"></script>
<script src="/js/popper.min.js"></script>
<script src="/js/bootstrap.min.js"></script>

<script src="/js/script.js"></script>
</body>

</html>