<?php
 require $_SERVER['DOCUMENT_ROOT'] . '/views/layouts/header.php';
?>

<?php
 require $_SERVER['DOCUMENT_ROOT'] . '/views/tender.php';
?>


<?php
 require $_SERVER['DOCUMENT_ROOT'] . '/views/layouts/footer.php';
?>